<?php
/**
 * Mengambil data laporan sesuai jenis (peminjaman / pengembalian / denda)
 * dalam rentang tanggal tertentu.
 */
function getLaporanData(PDO $pdo, string $jenis, string $dari, string $sampai): array
{
    if ($jenis === 'pengembalian') {
        $sql = "SELECT p.no_pinjam, a.nm_anggota, b.judul, dp.tgl_pinjam, dp.tgl_kembali, dp.status_pinjam
                FROM detpinjam dp
                JOIN pinjam p ON dp.no_pinjam = p.no_pinjam
                JOIN anggota a ON p.kd_anggota = a.kd_anggota
                JOIN inventaris i ON dp.no_inventaris = i.no_inventaris
                JOIN buku b ON i.kd_buku = b.kd_buku
                WHERE dp.status_pinjam = 'Kembali' AND dp.tgl_kembali BETWEEN ? AND ?
                ORDER BY dp.tgl_kembali DESC";
    } elseif ($jenis === 'denda') {
        $sql = "SELECT a.nm_anggota, b.judul, d.tgl_denda, d.jmlh_denda, d.lunas
                FROM denda d
                JOIN detpinjam dp ON d.id_detpinjam = dp.id_detpinjam
                JOIN pinjam p ON dp.no_pinjam = p.no_pinjam
                JOIN anggota a ON p.kd_anggota = a.kd_anggota
                JOIN inventaris i ON dp.no_inventaris = i.no_inventaris
                JOIN buku b ON i.kd_buku = b.kd_buku
                WHERE d.tgl_denda BETWEEN ? AND ?
                ORDER BY d.tgl_denda DESC";
    } else { // peminjaman (default)
        $jenis = 'peminjaman';
        $sql = "SELECT p.no_pinjam, a.nm_anggota, b.judul, dp.tgl_pinjam, p.tgl_harus_kembali, dp.status_pinjam
                FROM detpinjam dp
                JOIN pinjam p ON dp.no_pinjam = p.no_pinjam
                JOIN anggota a ON p.kd_anggota = a.kd_anggota
                JOIN inventaris i ON dp.no_inventaris = i.no_inventaris
                JOIN buku b ON i.kd_buku = b.kd_buku
                WHERE dp.tgl_pinjam BETWEEN ? AND ?
                ORDER BY p.no_pinjam DESC";
    }

    $stmt = $pdo->prepare($sql);
    $stmt->execute([$dari, $sampai]);
    return $stmt->fetchAll();
}
