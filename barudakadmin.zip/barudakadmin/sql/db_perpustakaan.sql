-- =========================================================
-- DATABASE: SISTEM INFORMASI PERPUSTAKAAN (PHP + MySQL)
-- Skema gabungan — dipakai bersama oleh semua halaman
-- (dashboard, data buku, pengarang/penerbit, anggota, petugas,
--  inventaris, peminjaman, pengembalian, denda, laporan, pengaturan).
--
-- Import file ini lewat phpMyAdmin (tab Import) atau
-- jalankan lewat tab SQL setelah membuat database kosong.
-- =========================================================

CREATE DATABASE IF NOT EXISTS db_perpustakaan CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE db_perpustakaan;

-- ---------------------------------------------------------
-- TABEL REFERENSI / MASTER
-- ---------------------------------------------------------

CREATE TABLE penerbit (
    kd_penerbit INT AUTO_INCREMENT PRIMARY KEY,
    nm_penerbit VARCHAR(150) NOT NULL,
    alamat TEXT
) ENGINE=InnoDB;

CREATE TABLE pengarang (
    kd_pengarang INT AUTO_INCREMENT PRIMARY KEY,
    nm_pengarang VARCHAR(150) NOT NULL,
    jenis_kelamin CHAR(1) DEFAULT 'L'
) ENGINE=InnoDB;

CREATE TABLE klasifikasi (
    kd_klasifikasi INT AUTO_INCREMENT PRIMARY KEY,
    nm_klasifikasi VARCHAR(100) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE buku (
    kd_buku INT AUTO_INCREMENT PRIMARY KEY,
    judul VARCHAR(255) NOT NULL,
    kd_penerbit INT,
    kd_klasifikasi INT,
    kd_pengarang INT,
    thn_terbit INT,
    bahasa VARCHAR(50),
    edisi VARCHAR(50),
    isbn VARCHAR(50),
    jumlah INT DEFAULT 0,
    FOREIGN KEY (kd_penerbit) REFERENCES penerbit(kd_penerbit) ON DELETE SET NULL,
    FOREIGN KEY (kd_klasifikasi) REFERENCES klasifikasi(kd_klasifikasi) ON DELETE SET NULL,
    FOREIGN KEY (kd_pengarang) REFERENCES pengarang(kd_pengarang) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE inventaris (
    no_inventaris INT AUTO_INCREMENT PRIMARY KEY,
    kd_buku INT NOT NULL,
    no_buku VARCHAR(50),
    tgl_masuk DATE,
    status ENUM('Tersedia','Dipinjam','Rusak','Hilang') DEFAULT 'Tersedia',
    FOREIGN KEY (kd_buku) REFERENCES buku(kd_buku) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- TABEL USER (Anggota, Petugas/Admin)
-- Kolom `foto` dipakai oleh halaman Profil (anggota/profil.php,
-- petugas/profil.php, admin/profil.php) untuk foto profil.
-- ---------------------------------------------------------

CREATE TABLE anggota (
    kd_anggota INT AUTO_INCREMENT PRIMARY KEY,
    nm_anggota VARCHAR(150) NOT NULL,
    jenis_kelamin CHAR(1) DEFAULT 'L',
    alamat TEXT,
    no_telp VARCHAR(30),
    foto VARCHAR(255) DEFAULT NULL,
    tgl_daftar DATE DEFAULT NULL,
    user VARCHAR(50) UNIQUE,
    password VARCHAR(255),
    status_aktif TINYINT(1) DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE petugas (
    kd_petugas INT AUTO_INCREMENT PRIMARY KEY,
    nm_petugas VARCHAR(150) NOT NULL,
    jenis_kelamin CHAR(1) DEFAULT 'L',
    alamat TEXT,
    telp VARCHAR(30),
    foto VARCHAR(255) DEFAULT NULL,
    user VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin','petugas') DEFAULT 'petugas',
    status_aktif TINYINT(1) DEFAULT 1
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- TRANSAKSI
-- ---------------------------------------------------------

CREATE TABLE pinjam (
    no_pinjam INT AUTO_INCREMENT PRIMARY KEY,
    kd_anggota INT NOT NULL,
    kd_petugas INT NOT NULL,
    tgl_pinjam DATE NOT NULL,
    tgl_harus_kembali DATE NOT NULL,
    FOREIGN KEY (kd_anggota) REFERENCES anggota(kd_anggota),
    FOREIGN KEY (kd_petugas) REFERENCES petugas(kd_petugas)
) ENGINE=InnoDB;

CREATE TABLE detpinjam (
    id_detpinjam INT AUTO_INCREMENT PRIMARY KEY,
    no_pinjam INT NOT NULL,
    no_inventaris INT NOT NULL,
    tgl_pinjam DATE NOT NULL,
    tgl_kembali DATE DEFAULT NULL,
    status_pinjam ENUM('Dipinjam','Kembali') DEFAULT 'Dipinjam',
    FOREIGN KEY (no_pinjam) REFERENCES pinjam(no_pinjam) ON DELETE CASCADE,
    FOREIGN KEY (no_inventaris) REFERENCES inventaris(no_inventaris)
) ENGINE=InnoDB;

CREATE TABLE denda (
    id_denda INT AUTO_INCREMENT PRIMARY KEY,
    id_detpinjam INT NOT NULL,
    tgl_denda DATE NOT NULL,
    jmlh_denda DECIMAL(12,2) DEFAULT 0,
    lunas TINYINT(1) DEFAULT 0,
    FOREIGN KEY (id_detpinjam) REFERENCES detpinjam(id_detpinjam) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- KONFIGURASI SISTEM (key-value, diatur Admin lewat Pengaturan)
-- ---------------------------------------------------------

CREATE TABLE konfigurasi (
    `key` VARCHAR(50) PRIMARY KEY,
    `value` VARCHAR(100) NOT NULL
) ENGINE=InnoDB;

INSERT INTO konfigurasi (`key`, `value`) VALUES
('lama_pinjam_hari', '7'),
('tarif_denda_per_hari', '1000');

-- ---------------------------------------------------------
-- SEED DATA CONTOH
-- Password untuk semua akun contoh di bawah adalah: password123
-- (hash dibuat dengan PHP password_hash / bcrypt)
-- ---------------------------------------------------------

INSERT INTO petugas (nm_petugas, jenis_kelamin, alamat, telp, user, password, role, status_aktif) VALUES
('Administrator', 'L', 'Kantor Perpustakaan', '081200000001', 'admin', '$2b$10$my/CM4dLagbbfMt1W1/QPuT4t2D2gPjfFdAnHIZlvYqP0exAfv04W', 'admin', 1),
('Budi Petugas', 'L', 'Jl. Melati No. 2', '081200000002', 'petugas1', '$2b$10$my/CM4dLagbbfMt1W1/QPuT4t2D2gPjfFdAnHIZlvYqP0exAfv04W', 'petugas', 1);

INSERT INTO anggota (nm_anggota, jenis_kelamin, alamat, no_telp, tgl_daftar, user, password, status_aktif) VALUES
('Budi Santoso', 'L', 'Jl. Mawar No. 1', '081300000001', CURDATE(), 'anggota1', '$2b$10$my/CM4dLagbbfMt1W1/QPuT4t2D2gPjfFdAnHIZlvYqP0exAfv04W', 1),
('Siti Aminah', 'P', 'Jl. Kenanga No. 5', '081300000002', CURDATE(), 'anggota2', '$2b$10$my/CM4dLagbbfMt1W1/QPuT4t2D2gPjfFdAnHIZlvYqP0exAfv04W', 1);

INSERT INTO penerbit (nm_penerbit, alamat) VALUES
('Informatika', 'Bandung'),
('Gramedia', 'Jakarta'),
('Erlangga', 'Jakarta');

INSERT INTO pengarang (nm_pengarang, jenis_kelamin) VALUES
('Rinaldi Munir', 'L'),
('Andrea Hirata', 'L'),
('Tere Liye', 'L');

INSERT INTO klasifikasi (nm_klasifikasi) VALUES
('Teknologi'),
('Fiksi'),
('Sains'),
('Sejarah');

INSERT INTO buku (judul, kd_penerbit, kd_klasifikasi, kd_pengarang, thn_terbit, bahasa, edisi, isbn, jumlah) VALUES
('Algoritma Pemrograman', 1, 1, 1, 2020, 'Indonesia', '1', '978-602-1234-01-1', 5),
('Laskar Pelangi', 2, 2, 2, 2005, 'Indonesia', '1', '978-602-1234-02-2', 3),
('Bumi', 3, 2, 3, 2014, 'Indonesia', '1', '978-602-1234-03-3', 4);

INSERT INTO inventaris (kd_buku, no_buku, tgl_masuk, status) VALUES
(1, 'B001-1', '2024-01-01', 'Tersedia'),
(1, 'B001-2', '2024-01-01', 'Tersedia'),
(2, 'B002-1', '2024-01-05', 'Tersedia'),
(3, 'B003-1', '2024-02-01', 'Tersedia');
