<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/laporan_helper.php';
require_role(['admin', 'petugas']);

$jenis  = $_GET['jenis'] ?? 'peminjaman';
if (!in_array($jenis, ['peminjaman', 'pengembalian', 'denda'])) $jenis = 'peminjaman';
$dari   = $_GET['dari'] ?? date('Y-m-01');
$sampai = $_GET['sampai'] ?? date('Y-m-d');

$rows = getLaporanData($pdo, $jenis, $dari, $sampai);

$page_title = 'Laporan';
$nama_user = $_SESSION['nama'];
$active = 'laporan';
require __DIR__ . '/../includes/header.php';
require __DIR__ . '/../includes/sidebar.php';
?>

<div class="panel">
    <div class="panel-header"><h2>Filter Laporan</h2></div>
    <div class="panel-body">
        <form method="get" class="form-grid">
            <div class="form-group">
                <label for="jenis">Jenis Laporan</label>
                <select id="jenis" name="jenis">
                    <option value="peminjaman" <?= $jenis === 'peminjaman' ? 'selected' : '' ?>>Peminjaman</option>
                    <option value="pengembalian" <?= $jenis === 'pengembalian' ? 'selected' : '' ?>>Pengembalian</option>
                    <option value="denda" <?= $jenis === 'denda' ? 'selected' : '' ?>>Denda</option>
                </select>
            </div>
            <div class="form-group">
                <label for="dari">Dari Tanggal</label>
                <input type="date" id="dari" name="dari" value="<?= e($dari) ?>">
            </div>
            <div class="form-group">
                <label for="sampai">Sampai Tanggal</label>
                <input type="date" id="sampai" name="sampai" value="<?= e($sampai) ?>">
            </div>
            <div class="form-group" style="align-self:end;">
                <button type="submit" class="btn btn-primary">Tampilkan</button>
            </div>
        </form>
    </div>
</div>

<div class="panel">
    <div class="panel-header">
        <h2>Hasil Laporan</h2>
        <a class="btn btn-outline btn-sm"
           href="<?= BASE_URL ?>/admin/laporan_export.php?jenis=<?= urlencode($jenis) ?>&dari=<?= urlencode($dari) ?>&sampai=<?= urlencode($sampai) ?>">
            Export CSV/Excel
        </a>
    </div>
    <div class="panel-body" style="padding:0">
    <table>
        <?php if ($jenis === 'pengembalian'): ?>
            <thead><tr><th>No. Pinjam</th><th>Anggota</th><th>Judul Buku</th><th>Tgl Pinjam</th><th>Tgl Kembali</th><th>Status</th></tr></thead>
            <tbody>
            <?php if (empty($rows)): ?>
                <tr><td colspan="6" class="empty-state">Tidak ada data.</td></tr>
            <?php else: foreach ($rows as $r): ?>
                <tr>
                    <td>#<?= (int)$r['no_pinjam'] ?></td>
                    <td><?= e($r['nm_anggota']) ?></td>
                    <td><?= e($r['judul']) ?></td>
                    <td><?= tgl_indo($r['tgl_pinjam']) ?></td>
                    <td><?= $r['tgl_kembali'] ? tgl_indo($r['tgl_kembali']) : '-' ?></td>
                    <td><?= badge_status($r['status_pinjam']) ?></td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>

        <?php elseif ($jenis === 'denda'): ?>
            <thead><tr><th>Anggota</th><th>Judul Buku</th><th>Tgl Denda</th><th>Jumlah</th><th>Status</th></tr></thead>
            <tbody>
            <?php if (empty($rows)): ?>
                <tr><td colspan="5" class="empty-state">Tidak ada data.</td></tr>
            <?php else: foreach ($rows as $r): ?>
                <tr>
                    <td><?= e($r['nm_anggota']) ?></td>
                    <td><?= e($r['judul']) ?></td>
                    <td><?= tgl_indo($r['tgl_denda']) ?></td>
                    <td><?= rupiah($r['jmlh_denda']) ?></td>
                    <td><?= badge_status($r['lunas'] ? 'Lunas' : 'Belum Lunas') ?></td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>

        <?php else: ?>
            <thead><tr><th>No. Pinjam</th><th>Anggota</th><th>Judul Buku</th><th>Tgl Pinjam</th><th>Harus Kembali</th><th>Status</th></tr></thead>
            <tbody>
            <?php if (empty($rows)): ?>
                <tr><td colspan="6" class="empty-state">Tidak ada data.</td></tr>
            <?php else: foreach ($rows as $r): ?>
                <tr>
                    <td>#<?= (int)$r['no_pinjam'] ?></td>
                    <td><?= e($r['nm_anggota']) ?></td>
                    <td><?= e($r['judul']) ?></td>
                    <td><?= tgl_indo($r['tgl_pinjam']) ?></td>
                    <td><?= tgl_indo($r['tgl_harus_kembali']) ?></td>
                    <td><?= badge_status($r['status_pinjam']) ?></td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        <?php endif; ?>
    </table>
    </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
