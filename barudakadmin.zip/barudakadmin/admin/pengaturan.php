<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_role(['admin']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $lama_pinjam = (int)($_POST['lama_pinjam'] ?? 7);
    $tarif_denda = (int)($_POST['tarif_denda'] ?? 0);

    set_konfigurasi($pdo, 'lama_pinjam_hari', (string)max(1, $lama_pinjam));
    set_konfigurasi($pdo, 'tarif_denda_per_hari', (string)max(0, $tarif_denda));

    flash_set('success', 'Konfigurasi berhasil disimpan.');
    header('Location: ' . BASE_URL . '/admin/pengaturan.php');
    exit;
}

$lama_pinjam_hari = get_konfigurasi($pdo, 'lama_pinjam_hari', 7);
$tarif_denda_per_hari = get_konfigurasi($pdo, 'tarif_denda_per_hari', 1000);

$page_title = 'Pengaturan Sistem';
$nama_user = $_SESSION['nama'];
$active = 'pengaturan';
require __DIR__ . '/../includes/header.php';
require __DIR__ . '/../includes/sidebar.php';
?>

<div class="panel">
    <div class="panel-header"><h2>Konfigurasi Peminjaman &amp; Denda</h2></div>
    <div class="panel-body">
        <form method="post">
            <div class="form-grid">
                <div class="form-group">
                    <label for="lama_pinjam">Lama Masa Pinjam (hari)</label>
                    <input type="number" id="lama_pinjam" name="lama_pinjam" min="1"
                           value="<?= e((string)$lama_pinjam_hari) ?>" required>
                </div>
                <div class="form-group">
                    <label for="tarif_denda">Tarif Denda per Hari (Rp)</label>
                    <input type="number" id="tarif_denda" name="tarif_denda" min="0"
                           value="<?= e((string)$tarif_denda_per_hari) ?>" required>
                </div>
            </div>
            <p class="empty-state" style="text-align:left;padding:0 0 16px;">Perubahan hanya berlaku untuk transaksi peminjaman/denda baru. Transaksi lama tidak akan terpengaruh.</p>
            <button type="submit" class="btn btn-primary">Simpan Konfigurasi</button>
        </form>
    </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
