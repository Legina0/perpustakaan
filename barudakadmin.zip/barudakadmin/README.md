# PerpusApp — Versi Admin Saja

Ini adalah versi pangkas dari project gabungan, **khusus bagian Admin**.

## Apa yang dihapus
- Folder `anggota/` dan `petugas/` (portal/halaman untuk role Anggota dan Petugas) — dihapus total.
- Folder `auth/` (`login.php`, `logout.php`) — dihapus, tidak ada proses login/logout lagi.
- Semua link menuju halaman login/logout dan menuju folder `anggota/`/`petugas/` di sidebar dan tombol "Batal" sudah dirapikan supaya tidak mengarah ke halaman yang sudah tidak ada.

## Cara kerja tanpa login
`includes/auth.php` sekarang otomatis mengisi session sebagai akun **Administrator**
(diambil dari tabel `petugas` dengan `role = 'admin'`) begitu file itu di-include —
tidak ada form login sama sekali. Jadi begitu `index.php` diakses, langsung
diarahkan ke `admin/dashboard.php`.

Fungsi `require_role([...])` di setiap halaman admin sengaja **dibiarkan ada**
di kode (supaya kamu tidak perlu edit satu-satu file), tapi sekarang isinya
cuma memastikan session admin tersedia — tidak lagi mengecek role tertentu.

## Struktur Folder
```
├── admin/       Semua halaman Admin (13 halaman)
├── config/      Koneksi database (PDO)
├── includes/    auth.php (auto-session admin), functions.php (helper),
│                header/sidebar/footer.php (layout), laporan_helper.php
├── assets/      css/style.css, js/live-search.js
├── sql/         db_perpustakaan.sql — skema database (tidak berubah)
└── index.php    Entry point, langsung ke admin/dashboard.php
```

> Catatan: tabel `anggota` dan `petugas` di database **tetap ada**, karena
> halaman admin (`admin/anggota.php`, `admin/petugas.php`, `admin/peminjaman.php`,
> dst.) tetap perlu data anggota & petugas untuk transaksi peminjaman/pengembalian.
> Yang dihilangkan hanyalah portal login terpisah untuk kedua role tersebut.

## Cara instalasi (XAMPP/Laragon)
1. Copy folder ini ke `htdocs/` (XAMPP) atau `www/` (Laragon).
2. Buka phpMyAdmin, buat database `db_perpustakaan`, lalu **Import**
   file `sql/db_perpustakaan.sql`.
3. Sesuaikan `config/database.php` kalau username/password MySQL kamu beda
   dari default XAMPP/Laragon (`root` / tanpa password).
4. Akses lewat browser: `http://localhost/<nama_folder>/` — langsung masuk
   ke Dashboard Admin, tanpa login.
