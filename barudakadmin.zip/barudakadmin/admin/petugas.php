<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_role(['admin']);

$msg = '';
$msgType = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (isset($_POST['add'])) {
            $hash = password_hash($_POST['password'] !== '' ? $_POST['password'] : 'petugas123', PASSWORD_BCRYPT);
            $stmt = $pdo->prepare("INSERT INTO petugas (nm_petugas, jenis_kelamin, alamat, telp, user, password, role, status_aktif)
                                    VALUES (?, ?, ?, ?, ?, ?, ?, 1)");
            $stmt->execute([
                trim($_POST['nm_petugas']),
                $_POST['jenis_kelamin'],
                trim($_POST['alamat']),
                trim($_POST['telp']),
                trim($_POST['user']),
                $hash,
                $_POST['role'],
            ]);
            $msg = 'Akun petugas baru berhasil ditambahkan (password default: petugas123 jika dikosongkan).';
        } elseif (isset($_POST['edit'])) {
            // Cegah admin terakhir diturunkan rolenya jadi petugas
            $kd = (int)$_POST['kd_petugas'];
            if ($_POST['role'] !== 'admin') {
                $jumlah_admin_aktif = (int)$pdo->query("SELECT COUNT(*) c FROM petugas WHERE role='admin' AND status_aktif=1")->fetch()['c'];
                $ini_admin = $pdo->prepare("SELECT role FROM petugas WHERE kd_petugas=?");
                $ini_admin->execute([$kd]);
                $roleLama = $ini_admin->fetchColumn();
                if ($roleLama === 'admin' && $jumlah_admin_aktif <= 1) {
                    throw new RuntimeException('Tidak bisa mengubah role admin terakhir.');
                }
            }
            $stmt = $pdo->prepare("UPDATE petugas SET nm_petugas=?, jenis_kelamin=?, alamat=?, telp=?, user=?, role=? WHERE kd_petugas=?");
            $stmt->execute([
                trim($_POST['nm_petugas']),
                $_POST['jenis_kelamin'],
                trim($_POST['alamat']),
                trim($_POST['telp']),
                trim($_POST['user']),
                $_POST['role'],
                $kd,
            ]);
            $msg = 'Data petugas berhasil diubah.';
        } elseif (isset($_POST['reset_pass'])) {
            $hash = password_hash('petugas123', PASSWORD_BCRYPT);
            $stmt = $pdo->prepare("UPDATE petugas SET password=? WHERE kd_petugas=?");
            $stmt->execute([$hash, $_POST['kd_petugas']]);
            $msg = 'Password berhasil direset ke default (petugas123).';
        } elseif (isset($_POST['toggle_status'])) {
            $kd = (int)$_POST['kd_petugas'];
            $cek = $pdo->prepare("SELECT role, status_aktif FROM petugas WHERE kd_petugas=?");
            $cek->execute([$kd]);
            $row = $cek->fetch();
            if ($row && $row['role'] === 'admin' && $row['status_aktif'] == 1) {
                $jumlah_admin_aktif = (int)$pdo->query("SELECT COUNT(*) c FROM petugas WHERE role='admin' AND status_aktif=1")->fetch()['c'];
                if ($jumlah_admin_aktif <= 1) {
                    throw new RuntimeException('Tidak bisa menonaktifkan admin terakhir.');
                }
            }
            $stmt = $pdo->prepare("UPDATE petugas SET status_aktif = 1 - status_aktif WHERE kd_petugas=?");
            $stmt->execute([$kd]);
            $msg = 'Status akun berhasil diperbarui.';
        }
    } catch (RuntimeException $ex) {
        $msg = $ex->getMessage();
        $msgType = 'error';
    } catch (PDOException $ex) {
        $msg = 'Gagal: username mungkin sudah dipakai, atau terjadi kesalahan.';
        $msgType = 'error';
    }
}

$search = trim($_GET['q'] ?? '');
if ($search !== '') {
    $stmt = $pdo->prepare("SELECT * FROM petugas WHERE nm_petugas LIKE ? OR user LIKE ? ORDER BY nm_petugas ASC");
    $like = "%$search%";
    $stmt->execute([$like, $like]);
    $petugasList = $stmt->fetchAll();
} else {
    $petugasList = $pdo->query("SELECT * FROM petugas ORDER BY nm_petugas ASC")->fetchAll();
}

$editPetugas = null;
if (isset($_GET['edit_id'])) {
    $stmt = $pdo->prepare("SELECT * FROM petugas WHERE kd_petugas=?");
    $stmt->execute([$_GET['edit_id']]);
    $editPetugas = $stmt->fetch();
}

$page_title = 'Kelola Akun Petugas';
$nama_user = $_SESSION['nama'];
$active = 'petugas';
require __DIR__ . '/../includes/header.php';
require __DIR__ . '/../includes/sidebar.php';
?>

<?php if ($msg): ?>
    <div class="alert alert-<?= $msgType === 'error' ? 'error' : 'success' ?>"><?= e($msg) ?></div>
<?php endif; ?>

<div class="panel">
    <div class="panel-header"><h2><?= $editPetugas ? 'Ubah Akun' : 'Tambah Akun Baru' ?></h2></div>
    <div class="panel-body">
        <form method="post">
            <?php if ($editPetugas): ?>
                <input type="hidden" name="kd_petugas" value="<?= (int)$editPetugas['kd_petugas'] ?>">
            <?php endif; ?>
            <div class="form-grid">
                <div class="form-group">
                    <label>Nama</label>
                    <input type="text" name="nm_petugas" required value="<?= e($editPetugas['nm_petugas'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Username</label>
                    <input type="text" name="user" required value="<?= e($editPetugas['user'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Role</label>
                    <select name="role">
                        <option value="petugas" <?= (($editPetugas['role'] ?? 'petugas') === 'petugas') ? 'selected' : '' ?>>Petugas</option>
                        <option value="admin" <?= (($editPetugas['role'] ?? '') === 'admin') ? 'selected' : '' ?>>Admin</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>No. Telepon</label>
                    <input type="text" name="telp" inputmode="numeric" pattern="[0-9]{8,15}" value="<?= e($editPetugas['telp'] ?? '') ?>">
                </div>
                <?php if (!$editPetugas): ?>
                <div class="form-group">
                    <label>Password (kosongkan utk default "petugas123")</label>
                    <input type="password" name="password">
                </div>
                <?php endif; ?>
                <div class="form-group">
                    <label>Jenis Kelamin</label>
                    <select name="jenis_kelamin">
                        <option value="L" <?= (($editPetugas['jenis_kelamin'] ?? 'L') === 'L') ? 'selected' : '' ?>>Laki-laki</option>
                        <option value="P" <?= (($editPetugas['jenis_kelamin'] ?? '') === 'P') ? 'selected' : '' ?>>Perempuan</option>
                    </select>
                </div>
            </div>
            <div class="form-group" style="margin-bottom:18px;">
                <label>Alamat</label>
                <textarea name="alamat" rows="2"><?= e($editPetugas['alamat'] ?? '') ?></textarea>
            </div>
            <button type="submit" name="<?= $editPetugas ? 'edit' : 'add' ?>" class="btn btn-primary">
                <?= $editPetugas ? 'Simpan Perubahan' : 'Tambah Akun' ?>
            </button>
            <?php if ($editPetugas): ?>
                <a href="<?= BASE_URL ?>/admin/petugas.php" class="btn btn-outline">Batal</a>
            <?php endif; ?>
        </form>
    </div>
</div>

<div class="panel">
    <div class="panel-header">
        <h2>Daftar Akun Petugas/Admin</h2>
        <form class="search-box" method="get">
            <input type="text" name="q" placeholder="Cari nama/username..." value="<?= e($search) ?>">
            <button type="submit" class="btn btn-primary">Cari</button>
        </form>
    </div>
    <div class="panel-body" style="padding:0">
        <table>
            <thead><tr><th>Nama</th><th>Username</th><th>Role</th><th>Status</th><th>Aksi</th></tr></thead>
            <tbody>
            <?php if (empty($petugasList)): ?>
                <tr><td colspan="5" class="empty-state">Tidak ada data ditemukan.</td></tr>
            <?php else: foreach ($petugasList as $row): ?>
                <tr>
                    <td><?= e($row['nm_petugas']) ?></td>
                    <td><?= e($row['user']) ?></td>
                    <td><?= badge_status(strtoupper($row['role'])) ?></td>
                    <td><?= badge_status($row['status_aktif'] ? 'Aktif' : 'Nonaktif') ?></td>
                    <td>
                        <a class="btn btn-outline btn-sm" href="?edit_id=<?= (int)$row['kd_petugas'] ?>">Ubah</a>
                        <form method="post" style="display:inline" onsubmit="return confirm('Reset password ke default?');">
                            <input type="hidden" name="kd_petugas" value="<?= (int)$row['kd_petugas'] ?>">
                            <button type="submit" name="reset_pass" class="btn btn-outline btn-sm">Reset Pass</button>
                        </form>
                        <form method="post" style="display:inline" onsubmit="return confirm('Ubah status aktif akun ini?');">
                            <input type="hidden" name="kd_petugas" value="<?= (int)$row['kd_petugas'] ?>">
                            <button type="submit" name="toggle_status" class="btn <?= $row['status_aktif'] ? 'btn-danger' : 'btn-primary' ?> btn-sm">
                                <?= $row['status_aktif'] ? 'Nonaktifkan' : 'Aktifkan' ?>
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
