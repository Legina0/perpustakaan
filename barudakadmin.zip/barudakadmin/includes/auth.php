<?php
/**
 * Versi tanpa login/logout.
 * Karena aplikasi ini hanya dipakai oleh Admin, session di-set otomatis
 * ke akun Administrator (kd_petugas = 1, role = admin) begitu file ini
 * di-include, tanpa perlu form login sama sekali.
 *
 * Panggil require_once ini setelah database.php di setiap halaman admin.
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Pastikan session admin selalu tersedia.
 * $pdo harus sudah di-include lewat config/database.php sebelum fungsi ini dipanggil.
 */
function ensure_admin_session(): void
{
    global $pdo;

    if (isset($_SESSION['user_id']) && isset($_SESSION['role'])) {
        return;
    }

    $stmt = $pdo->prepare("SELECT kd_petugas, nm_petugas FROM petugas WHERE role = 'admin' AND status_aktif = 1 ORDER BY kd_petugas ASC LIMIT 1");
    $stmt->execute();
    $admin = $stmt->fetch();

    $_SESSION['user_id'] = $admin['kd_petugas'] ?? 1;
    $_SESSION['nama']    = $admin['nm_petugas'] ?? 'Administrator';
    $_SESSION['role']    = 'admin';
}

function is_logged_in(): bool
{
    return true;
}

function current_role(): ?string
{
    return 'admin';
}

/**
 * Tidak ada lagi halaman login, jadi cukup pastikan session admin siap.
 */
function require_login(): void
{
    ensure_admin_session();
}

/**
 * Karena hanya ada role admin, cukup pastikan session siap.
 * Parameter $allowed_roles dibiarkan agar pemanggilan lama (require_role([...]))
 * di halaman admin/*.php tidak perlu diubah satu-satu.
 */
function require_role(array $allowed_roles): void
{
    ensure_admin_session();
}

/**
 * Tidak ada lagi role lain, jadi langsung ke dashboard admin.
 */
function redirect_to_dashboard(): void
{
    header('Location: ' . BASE_URL . '/admin/dashboard.php');
    exit;
}
