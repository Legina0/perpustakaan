<?php
/**
 * Variabel yang harus disediakan sebelum include:
 * $active   -> string kode menu aktif, contoh 'dashboard', 'buku', dll
 * $page_title, $nama_user
 * current_role() dipakai untuk menentukan menu
 */
$role = 'admin';

// Ambil foto profil admin yang sedang aktif (dari tabel petugas)
$foto_user_url = null;
if (isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare("SELECT foto FROM petugas WHERE kd_petugas = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $foto_user_url = foto_profil_url($stmt->fetchColumn() ?: null);
}

$menu_admin = [
    'dashboard'      => ['Dashboard', BASE_URL . '/admin/dashboard.php'],
    'grafik'         => ['Dashboard Grafik', BASE_URL . '/admin/dashboard_grafik.php'],
    'buku'           => ['Data Buku', BASE_URL . '/admin/data_buku.php'],
    'pengarang'      => ['Pengarang/Penerbit', BASE_URL . '/admin/pengarang_penerbit.php'],
    'anggota'        => ['Anggota', BASE_URL . '/admin/anggota.php'],
    'petugas'        => ['Petugas', BASE_URL . '/admin/petugas.php'],
    'inventaris'     => ['Inventaris', BASE_URL . '/admin/inventaris.php'],
    'peminjaman'     => ['Peminjaman', BASE_URL . '/admin/peminjaman.php'],
    'pengembalian'   => ['Pengembalian', BASE_URL . '/admin/pengembalian.php'],
    'denda'          => ['Denda', BASE_URL . '/admin/denda.php'],
    'laporan'        => ['Laporan', BASE_URL . '/admin/laporan.php'],
    'pengaturan'     => ['Pengaturan', BASE_URL . '/admin/pengaturan.php'],
    'profil'         => ['Profil', BASE_URL . '/admin/profil.php'],
];

$menu = $menu_admin;
?>
<aside class="sidebar">
    <div class="brand">&#128218; PerpusApp</div>
    <span class="role-badge admin">ADMIN</span>
    <nav>
        <?php foreach ($menu as $key => [$label, $url]): ?>
            <a href="<?= $url ?>" class="<?= ($active ?? '') === $key ? 'active' : '' ?> admin-menu">
                <?= e($label) ?>
            </a>
        <?php endforeach; ?>
    </nav>
</aside>
<div class="main">
    <div class="topbar">
        <h1><?= e($page_title ?? '') ?></h1>
        <div class="user-menu" id="userMenu">
            <div class="user-chip" onclick="document.getElementById('userMenu').classList.toggle('open')">
                <div class="avatar-circle">
                    <?php if ($foto_user_url): ?>
                        <img src="<?= e($foto_user_url) ?>" alt="Foto Profil">
                    <?php else: ?>
                        <?= svg_avatar_placeholder() ?>
                    <?php endif; ?>
                </div>
                <span class="user-chip-name"><?= e($nama_user ?? 'User') ?></span>
            </div>
            <div class="user-dropdown">
                <a href="<?= BASE_URL ?>/admin/profil.php">Profil Saya</a>
            </div>
        </div>
    </div>
    <div class="content">
        <?php if ($f = flash_get()): ?>
            <script>
            document.addEventListener('DOMContentLoaded', function () {
                Swal.fire({
                    icon: <?= json_encode($f['type'] === 'error' ? 'error' : 'success') ?>,
                    title: <?= json_encode($f['type'] === 'error' ? 'Gagal' : 'Berhasil') ?>,
                    text: <?= json_encode($f['message']) ?>,
                    confirmButtonColor: '#4f46e5',
                    <?php if ($f['type'] !== 'error'): ?>
                    timer: 2200,
                    timerProgressBar: true,
                    <?php endif; ?>
                });
            });
            </script>
        <?php endif; ?>
