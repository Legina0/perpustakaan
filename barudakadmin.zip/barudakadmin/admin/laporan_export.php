<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/laporan_helper.php';
require_role(['admin', 'petugas']);

$jenis  = $_GET['jenis'] ?? 'peminjaman';
if (!in_array($jenis, ['peminjaman', 'pengembalian', 'denda'])) $jenis = 'peminjaman';
$dari   = $_GET['dari'] ?? date('Y-m-01');
$sampai = $_GET['sampai'] ?? date('Y-m-d');

$rows = getLaporanData($pdo, $jenis, $dari, $sampai);

$filename = 'laporan_' . $jenis . '_' . $dari . '_sd_' . $sampai . '.csv';

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');

$output = fopen('php://output', 'w');
// BOM supaya karakter terbaca benar saat dibuka di Excel
fwrite($output, chr(0xEF) . chr(0xBB) . chr(0xBF));

if ($jenis === 'pengembalian') {
    fputcsv($output, ['No. Pinjam', 'Anggota', 'Judul Buku', 'Tgl Pinjam', 'Tgl Kembali', 'Status']);
    foreach ($rows as $r) {
        fputcsv($output, [$r['no_pinjam'], $r['nm_anggota'], $r['judul'], $r['tgl_pinjam'], $r['tgl_kembali'], $r['status_pinjam']]);
    }
} elseif ($jenis === 'denda') {
    fputcsv($output, ['Anggota', 'Judul Buku', 'Tgl Denda', 'Jumlah', 'Status']);
    foreach ($rows as $r) {
        fputcsv($output, [$r['nm_anggota'], $r['judul'], $r['tgl_denda'], $r['jmlh_denda'], $r['lunas'] ? 'Lunas' : 'Belum Lunas']);
    }
} else {
    fputcsv($output, ['No. Pinjam', 'Anggota', 'Judul Buku', 'Tgl Pinjam', 'Harus Kembali', 'Status']);
    foreach ($rows as $r) {
        fputcsv($output, [$r['no_pinjam'], $r['nm_anggota'], $r['judul'], $r['tgl_pinjam'], $r['tgl_harus_kembali'], $r['status_pinjam']]);
    }
}

fclose($output);
exit;
