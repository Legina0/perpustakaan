<?php
/**
 * Konfigurasi koneksi database.
 * Sesuaikan DB_HOST, DB_NAME, DB_USER, DB_PASS dengan pengaturan
 * MySQL / phpMyAdmin di komputer/hosting kamu.
 */

// BASE_URL otomatis terdeteksi dari lokasi folder project di dalam htdocs/www,
// supaya semua link (css, gambar, redirect) tetap benar walau nama foldernya
// diganti atau diakses lewat subfolder (mis. /perpustakaan).
if (!defined('BASE_URL')) {
    $projectRoot = str_replace('\\', '/', realpath(__DIR__ . '/..'));
    $docRoot = str_replace('\\', '/', realpath($_SERVER['DOCUMENT_ROOT']));
    $base = '';
    if ($docRoot && strpos($projectRoot, $docRoot) === 0) {
        $base = substr($projectRoot, strlen($docRoot));
    }
    define('BASE_URL', rtrim($base, '/'));
}

define('DB_HOST', 'localhost');
define('DB_NAME', 'db_perpustakaan2');
define('DB_USER', 'root');
define('DB_PASS', '');

try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    die('Koneksi database gagal: ' . htmlspecialchars($e->getMessage()));
}
