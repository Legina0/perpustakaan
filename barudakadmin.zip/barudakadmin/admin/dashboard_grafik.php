<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_role(['admin']);

// Tren peminjaman 6 bulan terakhir
$stmt = $pdo->query("SELECT DATE_FORMAT(tgl_pinjam, '%Y-%m') bulan, COUNT(*) jumlah
    FROM pinjam
    WHERE tgl_pinjam >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
    GROUP BY bulan ORDER BY bulan");
$tren = $stmt->fetchAll();
$max_tren = max(array_merge(array_column($tren, 'jumlah'), [1]));

// Buku terpopuler (top 5)
$stmt = $pdo->query("SELECT b.judul, COUNT(dp.id_detpinjam) jml
    FROM detpinjam dp
    JOIN inventaris i ON i.no_inventaris = dp.no_inventaris
    JOIN buku b ON b.kd_buku = i.kd_buku
    GROUP BY b.kd_buku
    ORDER BY jml DESC LIMIT 5");
$populer = $stmt->fetchAll();
$max_populer = max(array_merge(array_column($populer, 'jml'), [1]));

$page_title = 'Dashboard Grafik';
$nama_user = $_SESSION['nama'];
$active = 'grafik';
require __DIR__ . '/../includes/header.php';
require __DIR__ . '/../includes/sidebar.php';
?>

<div class="grid-2">
    <div class="panel">
        <div class="panel-header"><h2>Tren Peminjaman (6 Bulan Terakhir)</h2></div>
        <div class="panel-body">
            <?php if (empty($tren)): ?>
                <p class="empty-state">Belum ada data peminjaman.</p>
            <?php else: foreach ($tren as $t): ?>
                <div style="margin-bottom:14px;">
                    <div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:4px;">
                        <span><?= e($t['bulan']) ?></span><span><strong><?= (int)$t['jumlah'] ?></strong></span>
                    </div>
                    <div style="background:#e5e7eb;border-radius:6px;height:14px;">
                        <div style="background:#2f5be0;height:14px;border-radius:6px;width:<?= max(4, round($t['jumlah'] / $max_tren * 100)) ?>%;"></div>
                    </div>
                </div>
            <?php endforeach; endif; ?>
        </div>
    </div>

    <div class="panel">
        <div class="panel-header"><h2>Buku Terpopuler (Top 5)</h2></div>
        <div class="panel-body">
            <?php if (empty($populer)): ?>
                <p class="empty-state">Belum ada data peminjaman.</p>
            <?php else: foreach ($populer as $p): ?>
                <div style="margin-bottom:14px;">
                    <div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:4px;">
                        <span><?= e($p['judul']) ?></span><span><strong><?= (int)$p['jml'] ?>x</strong></span>
                    </div>
                    <div style="background:#e5e7eb;border-radius:6px;height:14px;">
                        <div style="background:#f59e0b;height:14px;border-radius:6px;width:<?= max(4, round($p['jml'] / $max_populer * 100)) ?>%;"></div>
                    </div>
                </div>
            <?php endforeach; endif; ?>
        </div>
    </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
