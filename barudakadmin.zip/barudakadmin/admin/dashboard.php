<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_role(['admin']);

$total_buku = $pdo->query("SELECT COUNT(*) c FROM buku")->fetch()['c'];
$anggota_aktif = $pdo->query("SELECT COUNT(*) c FROM anggota WHERE status_aktif=1")->fetch()['c'];
$peminjaman_aktif = $pdo->query("SELECT COUNT(*) c FROM detpinjam WHERE status_pinjam='Dipinjam'")->fetch()['c'];
$terlambat = $pdo->query("SELECT COUNT(*) c FROM detpinjam dp JOIN pinjam p ON p.no_pinjam=dp.no_pinjam WHERE dp.status_pinjam='Dipinjam' AND p.tgl_harus_kembali < CURDATE()")->fetch()['c'];

// Ringkasan laporan cepat: 5 kategori
$ringkasan = [];
$ringkasan[] = ['Total Buku', $total_buku, 'Saat ini'];
$ringkasan[] = ['Anggota Aktif', $anggota_aktif, 'Saat ini'];
$ringkasan[] = ['Peminjaman Aktif', $peminjaman_aktif, 'Saat ini'];
$ringkasan[] = ['Keterlambatan', $terlambat, 'Saat ini'];
$total_denda_bulan_ini = $pdo->query("SELECT COALESCE(SUM(jmlh_denda),0) t FROM denda WHERE MONTH(tgl_denda)=MONTH(CURDATE()) AND YEAR(tgl_denda)=YEAR(CURDATE())")->fetch()['t'];
$ringkasan[] = ['Denda Bulan Ini', rupiah($total_denda_bulan_ini), date('F Y')];

$page_title = 'Dashboard Admin';
$nama_user = $_SESSION['nama'];
$active = 'dashboard';
require __DIR__ . '/../includes/header.php';
require __DIR__ . '/../includes/sidebar.php';
?>

<div class="cards">
    <div class="card c-red"><div class="label">Total Buku</div><div class="value"><?= (int)$total_buku ?></div></div>
    <div class="card c-green"><div class="label">Anggota Aktif</div><div class="value"><?= (int)$anggota_aktif ?></div></div>
    <div class="card c-orange"><div class="label">Peminjaman Aktif</div><div class="value"><?= (int)$peminjaman_aktif ?></div></div>
    <div class="card c-red"><div class="label">Keterlambatan</div><div class="value"><?= (int)$terlambat ?></div></div>
</div>

<div class="panel">
    <div class="panel-header">
        <h2>Ringkasan Laporan Cepat</h2>
        <a href="<?= BASE_URL ?>/admin/dashboard_grafik.php" class="btn btn-outline btn-sm">Lihat Grafik &rarr;</a>
    </div>
    <div class="panel-body" style="padding:0">
        <table>
            <thead><tr><th>Kategori</th><th>Jumlah</th><th>Periode</th></tr></thead>
            <tbody>
            <?php foreach ($ringkasan as $i => $r): ?>
                <tr><td><?= (int)$i + 1 ?>. <?= e($r[0]) ?></td><td><?= is_int($r[1]) ? $r[1] : e($r[1]) ?></td><td><?= e($r[2]) ?></td></tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
